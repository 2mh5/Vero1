---
name: Discord voice-channel behavior
description: User-approved limits and expected behavior for voice joining in this Discord bot.
---

Each bot account should maintain one active voice connection per server. A Come command joins the sender's voice channel or moves the addressed bot there; Go only disconnects that bot when invoked by a member currently in its connected channel. Multiple bot accounts may join the same or different channels, each with an independent voice connection. Bots join self-deafened and do not play audio.

**Why:** Discord permits only one voice-channel connection per bot account in a server; the user wants up to five accounts to be bound independently while retaining the existing Come/Go behavior.

**How to apply:** Give each Discord client its own voice connection group. Preserve the one-channel-per-account rule; never disconnect or move a different bot account when processing Come or Go.
