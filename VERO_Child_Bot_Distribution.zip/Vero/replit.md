# Running the Discord bot on Replit

This is a Node.js Discord.js bot, not a web application. Its interface is inside Discord; no browser preview or HTTP server is needed.

## Run

- Node.js 22 is configured.
- Dependencies are installed and pinned by `package-lock.json`. Use `npm ci` to restore them.
- The **Discord bot** workflow runs `npm start` from the project root.
- Add `DISCORD_TOKEN` and `OWNER_ID` in Replit Secrets before starting. Optionally add `DISCORD_TOKEN_2` through `DISCORD_TOKEN_5` for up to four additional voice bots. Never paste tokens into chat or commit them.
- `DEFAULT_PREFIX` is optional; the default is `!`.

## Discord setup

1. Create a bot application at https://discord.com/developers/applications.
2. On its Bot page, enable **Message Content Intent** and **Server Members Intent**.
3. Invite the bot with permission to view channels, send messages, embed links, and connect to voice channels. Give it **Manage Nicknames** if it should change its server nickname.
4. To obtain `OWNER_ID`, enable Developer Mode in Discord, right-click your own account, and copy its user ID.
5. Click Run. A successful connection prints the logged-in bot identity in the Console.
6. As the owner, use `!help`, `!bots`, `!broadcast`, or mention the main bot with `settings` in your server.

## Bot settings and voice

- Bot settings are owner-only. Mention the bot and use `settings` for the full command list.
- `setname` changes the bot's nickname in the current server. `setuser` changes the global bot username. `setavatar` and `setbanner` take an attached image or a reply to a message containing one.
- `setdefault` restores the original username and profile images recorded before the first profile edit, and restores saved nicknames in servers where the nickname was changed with `setname`.
- Status and activity are saved across restarts. The default activity is **Playing Vero**.
- To join voice, connect to a voice channel and type `Come @BotUser` in its chat. Type `Go @BotUser` from that same voice channel to make the bot leave.
- Each bot account can be connected to only one voice channel per server at a time. Each additional bot has an independent connection, so multiple bot accounts may join the same channel or separate channels. A `Come` from another channel moves the addressed bot there. It joins self-deafened and does not play audio.
- `!voicepanel` opens a main-bot control panel where an authorized user can select bot accounts and join them to their current voice channel or leave them from that channel. `Join all five` binds every ready bot at once.
- Child bots answer only their own `Come @BotUser` / `Go @BotUser` commands. The main bot remains the only account with the broadcast control panel.
- Voice commands follow the server's existing owner/allowlist access rules. The bot needs **View Channel** and **Connect** permissions for the target voice channel.

Use broadcasts only for announcements recipients expect. Setup checks must not send broadcasts.

## Storage and troubleshooting

- Settings and campaign logs are stored locally in `data/store.json`; keep this directory private and back it up before moving the bot.
- Missing credentials cause an explicit startup error.
- If Discord rejects the connection, check the token and privileged intents.
- If commands do not respond, check Message Content Intent and channel permissions.
- Closed DMs can prevent delivery; the bot cannot bypass Discord privacy settings.
- The original ZIP is retained; the extracted repository contents are at the project root.
