const { createHash } = require("node:crypto");
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

const RECIPIENTS_PER_BATCH = 5;
const MIN_DELAY_MS = 3000;
const MAX_DELAY_MS = 5000;
const MAX_HISTORY_PAGES = 200;

function formatCairoTime(value) {
  if (!value) return "—";
  return `${new Intl.DateTimeFormat("en-GB", {
    timeZone: "Africa/Cairo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).format(new Date(value))} Cairo`;
}

function campaignCounts(campaign) {
  const deliveries = Object.values(campaign.deliveries || {});
  return {
    sent: deliveries.filter(delivery => delivery.status === "sent").length,
    failed: deliveries.filter(delivery => delivery.status === "failed").length,
    uncertain: deliveries.filter(delivery => delivery.status === "uncertain").length,
    processed: deliveries.filter(delivery => ["sent", "failed", "uncertain"].includes(delivery.status)).length
  };
}

function campaignNonce(campaignId, userId) {
  return createHash("sha256").update(`${campaignId}:${userId}`).digest("hex").slice(0, 22);
}

function createCampaignManager({ client, store, saveStore, makePreview, sleep, onError = console.error }) {
  store.campaigns ||= [];
  const messageCache = new Map();
  let workerRunning = false;
  let retryTimer = null;

  function findCampaign(id) {
    return store.campaigns.find(campaign => campaign.id === id);
  }

  function buildProgressEmbed(campaign) {
    const counts = campaignCounts(campaign);
    const total = campaign.recipientIds.length;
    const remaining = Math.max(0, total - counts.processed);
    const nextAt = campaign.nextSendAt
      ? Math.max(Date.now(), campaign.nextSendAt)
      : Date.now();
    const estimatedCompletion = campaign.completedAt
      ? formatCairoTime(campaign.completedAt)
      : remaining
        ? formatCairoTime(nextAt + Math.max(0, remaining - 1) * 4000 + remaining * 750)
        : "—";
    const title = campaign.status === "completed"
      ? "انتهت الحملة"
      : campaign.status === "cancelled"
        ? "تم إيقاف الحملة"
        : campaign.status === "paused"
          ? "الحملة متوقفة مؤقتاً"
          : "تقدم الحملة";
    const embed = new EmbedBuilder()
      .setColor(campaign.status === "completed" ? 0x57F287 : campaign.status === "cancelled" ? 0xFAA61A : campaign.status === "paused" ? 0xED4245 : 0x5865F2)
      .setTitle(title)
      .setDescription([
        `المستلمون: ${total}`,
        `تم الإرسال: ${counts.sent}`,
        `فشل الإرسال: ${counts.failed}`,
        `حالة غير مؤكدة: ${counts.uncertain}`,
        `المتبقي: ${remaining}`,
        `الدفعة: ${RECIPIENTS_PER_BATCH} مستلمين كحد أقصى؛ الفاصل 3–5 ثوانٍ، وتُحترم أي مهلة إضافية يفرضها Discord.`,
        `رقم الدفعة الحالية: ${Math.floor(counts.processed / RECIPIENTS_PER_BATCH) + (remaining ? 1 : 0)}`,
        `بدأت: ${formatCairoTime(campaign.startedAt)}`,
        `آخر إرسال ناجح: ${formatCairoTime(campaign.lastSentAt)}`,
        `الإرسال التالي المتوقع: ${formatCairoTime(campaign.nextSendAt)}`,
        `الانتهاء المتوقع: ${estimatedCompletion}`
      ].join("\n"));
    if (campaign.lastError) {
      embed.addFields({ name: "ملاحظة", value: String(campaign.lastError).slice(0, 1000) });
    }
    return embed;
  }

  function progressComponents(campaign) {
    if (["completed", "cancelled"].includes(campaign.status)) return [];
    return [new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`campaign:cancel:${campaign.id}`)
        .setLabel("إيقاف الحملة")
        .setStyle(ButtonStyle.Danger)
    )];
  }

  async function getProgressMessage(campaign) {
    const cached = messageCache.get(campaign.id);
    if (cached) return cached;
    const channel = await client.channels.fetch(campaign.channelId);
    if (!channel?.send) throw new Error("تعذر الوصول إلى قناة متابعة الحملة.");
    if (campaign.progressMessageId && channel.messages?.fetch) {
      const existing = await channel.messages.fetch(campaign.progressMessageId).catch(() => null);
      if (existing) {
        messageCache.set(campaign.id, existing);
        return existing;
      }
    }
    const message = await channel.send({
      content: `متابعة حملة الإعلانات ${campaign.id}`,
      embeds: [buildProgressEmbed(campaign)],
      components: progressComponents(campaign)
    });
    campaign.progressMessageId = message.id;
    messageCache.set(campaign.id, message);
    saveStore();
    return message;
  }

  async function updateProgress(campaign) {
    try {
      const message = await getProgressMessage(campaign);
      await message.edit({
        content: `متابعة حملة الإعلانات ${campaign.id}`,
        embeds: [buildProgressEmbed(campaign)],
        components: progressComponents(campaign)
      });
    } catch (error) {
      onError("Could not update campaign progress:", error);
    }
  }

  async function findPriorDelivery(dmChannel, nonce, attemptStartedAt) {
    let before;
    const cutoff = Date.parse(attemptStartedAt) - 10_000;
    for (let page = 0; page < MAX_HISTORY_PAGES; page++) {
      let messages;
      try {
        messages = await dmChannel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
      } catch (error) {
        return { verified: false, error };
      }
      if (!messages.size) return { verified: true, message: null };
      const found = messages.find(message =>
        message.author?.id === client.user.id && String(message.nonce) === nonce
      );
      if (found) return { verified: true, message: found };
      const oldest = messages.last();
      if (!oldest || oldest.createdTimestamp < cutoff || messages.size < 100) {
        return { verified: true, message: null };
      }
      before = oldest.id;
    }
    return { verified: false, error: new Error("DM history exceeded the safe duplicate-check limit.") };
  }

  async function finalizeCampaign(campaign) {
    if (!campaign.completedAt) campaign.completedAt = new Date().toISOString();
    saveStore();
    await updateProgress(campaign);
    if (!campaign.logged) {
      const counts = campaignCounts(campaign);
      store.logs.push({
        id: campaign.id,
        guildId: campaign.guildId,
        initiatedBy: campaign.initiatedBy,
        startedAt: campaign.startedAt,
        completedAt: campaign.completedAt,
        lastSentAt: campaign.lastSentAt || null,
        audience: campaign.audience,
        attempted: counts.processed,
        sent: counts.sent,
        failed: counts.failed,
        uncertain: counts.uncertain,
        skipped: Math.max(0, campaign.recipientIds.length - counts.processed),
        cancelled: campaign.status === "cancelled"
      });
      if (store.logs.length > 200) store.logs = store.logs.slice(-200);
      campaign.logged = true;
      saveStore();
    }
    store.campaigns = store.campaigns.filter(item => item.id !== campaign.id);
    saveStore();
  }

  async function processCampaign(campaign) {
    if (campaign.status === "completed" || campaign.status === "cancelled") {
      return finalizeCampaign(campaign);
    }
    campaign.status = "running";
    campaign.startedAt ||= new Date().toISOString();
    campaign.deliveries ||= {};
    campaign.recipientIds ||= [];
    if (campaign.nextSendAt && campaign.nextSendAt > Date.now()) {
      await updateProgress(campaign);
      await sleep(campaign.nextSendAt - Date.now());
    }
    campaign.nextSendAt = null;
    saveStore();
    await updateProgress(campaign);

    for (let index = campaign.nextRecipientIndex || 0; index < campaign.recipientIds.length; index++) {
      if (campaign.cancelRequested) {
        campaign.status = "cancelled";
        campaign.nextRecipientIndex = index;
        saveStore();
        break;
      }

      const userId = campaign.recipientIds[index];
      let delivery = campaign.deliveries[userId];
      if (delivery && ["sent", "failed", "uncertain"].includes(delivery.status)) {
        campaign.nextRecipientIndex = index + 1;
        saveStore();
        continue;
      }

      try {
        const user = await client.users.fetch(userId);
        const dmChannel = await user.createDM();
        if (delivery?.status === "sending") {
          const recovery = await findPriorDelivery(dmChannel, delivery.nonce, delivery.attemptStartedAt);
          if (!recovery.verified) {
            delivery.status = "uncertain";
            delivery.error = "تعذر التحقق من سجل الخاص؛ تم التخطي لمنع إرسال نسخة مكررة.";
            campaign.nextRecipientIndex = index + 1;
            saveStore();
            await updateProgress(campaign);
            await waitBetweenRecipients(campaign, index);
            continue;
          }
          if (recovery.message) {
            delivery.status = "sent";
            delivery.sentAt = recovery.message.createdAt?.toISOString?.() || new Date().toISOString();
            delivery.messageId = recovery.message.id;
            campaign.lastSentAt = delivery.sentAt;
            campaign.nextRecipientIndex = index + 1;
            saveStore();
            await updateProgress(campaign);
            await waitBetweenRecipients(campaign, index);
            continue;
          }
        }

        delivery = campaign.deliveries[userId] ||= {};
        delivery.status = "sending";
        delivery.nonce ||= campaignNonce(campaign.id, userId);
        delivery.attemptStartedAt = new Date().toISOString();
        delete delivery.error;
        saveStore();

        const sentMessage = await dmChannel.send({
          ...makePreview(campaign.content, userId),
          nonce: delivery.nonce,
          enforceNonce: true
        });
        delivery.status = "sent";
        delivery.sentAt = sentMessage.createdAt?.toISOString?.() || new Date().toISOString();
        delivery.messageId = sentMessage.id;
        campaign.lastSentAt = delivery.sentAt;
      } catch (error) {
        delivery = campaign.deliveries[userId] ||= {};
        if (delivery.status === "sending") {
          delivery.status = "uncertain";
          delivery.error = "تعذر تأكيد نتيجة الإرسال؛ لن تتم إعادة المحاولة لتفادي التكرار.";
        } else {
          delivery.status = "failed";
          delivery.error = String(error.message || "تعذر إرسال الرسالة").slice(0, 200);
        }
        onError(`Could not send campaign ${campaign.id} to ${userId}:`, error);
      }

      campaign.nextRecipientIndex = index + 1;
      campaign.nextSendAt = null;
      saveStore();
      await updateProgress(campaign);
      await waitBetweenRecipients(campaign, index);
    }

    if (campaign.status !== "cancelled") campaign.status = "completed";
    campaign.nextSendAt = null;
    return finalizeCampaign(campaign);
  }

  async function waitBetweenRecipients(campaign, index) {
    if (index + 1 >= campaign.recipientIds.length || campaign.cancelRequested) return;
    const delay = MIN_DELAY_MS + Math.floor(Math.random() * (MAX_DELAY_MS - MIN_DELAY_MS + 1));
    campaign.nextSendAt = Date.now() + delay;
    saveStore();
    await updateProgress(campaign);
    await sleep(delay);
  }

  async function processQueue() {
    if (workerRunning) return;
    workerRunning = true;
    try {
      while (true) {
        const campaign = store.campaigns.find(item =>
          ["queued", "running", "paused", "completed", "cancelled"].includes(item.status)
        );
        if (!campaign) break;
        if (campaign.status === "paused") campaign.status = "queued";
        try {
          await processCampaign(campaign);
        } catch (error) {
          campaign.status = "paused";
          campaign.lastError = "تعذر حفظ الاتصال أو متابعة الإرسال؛ ستتم المحاولة مجدداً.";
          campaign.nextSendAt = null;
          saveStore();
          onError(`Campaign ${campaign.id} paused:`, error);
          await updateProgress(campaign);
          break;
        }
      }
    } finally {
      workerRunning = false;
    }
    if (store.campaigns.some(item => item.status === "paused") && !retryTimer) {
      retryTimer = setTimeout(() => {
        retryTimer = null;
        processQueue().catch(error => onError("Campaign queue retry failed:", error));
      }, 60_000);
      retryTimer.unref?.();
    }
  }

  async function enqueue(campaign, channel) {
    campaign.status = "queued";
    campaign.nextRecipientIndex = 0;
    campaign.deliveries = {};
    campaign.createdAt = new Date().toISOString();
    campaign.progressMessageId = null;
    store.campaigns.push(campaign);
    saveStore();
    let message;
    try {
      message = await channel.send({
        content: `متابعة حملة الإعلانات ${campaign.id}`,
        embeds: [buildProgressEmbed(campaign)],
        components: progressComponents(campaign)
      });
    } catch (error) {
      store.campaigns = store.campaigns.filter(item => item.id !== campaign.id);
      saveStore();
      throw error;
    }
    campaign.progressMessageId = message.id;
    messageCache.set(campaign.id, message);
    saveStore();
    processQueue().catch(error => onError("Campaign queue failed:", error));
    return message;
  }

  function cancel(campaignId, userId) {
    const campaign = findCampaign(campaignId);
    if (!campaign) return { ok: false, reason: "not_found" };
    if (campaign.initiatedBy !== userId && userId !== process.env.OWNER_ID) {
      return { ok: false, reason: "not_owner" };
    }
    campaign.cancelRequested = true;
    saveStore();
    updateProgress(campaign);
    return { ok: true };
  }

  function resume() {
    processQueue().catch(error => onError("Could not resume campaign queue:", error));
  }

  return { enqueue, cancel, resume };
}

module.exports = { createCampaignManager, campaignNonce, formatCairoTime };
