const {
  Client,
  GatewayIntentBits,
  Partials,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  ActivityType,
  PermissionsBitField,
  Routes,
} = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");
const { lookup } = require("node:dns/promises");
const { isIP } = require("node:net");
const {
  entersState,
  getVoiceConnection,
  joinVoiceChannel,
  VoiceConnectionStatus,
} = require("@discordjs/voice");

const TOKEN = process.env.DISCORD_TOKEN;
const OWNER_ID = process.env.OWNER_ID;
if (!TOKEN || !OWNER_ID) {
  console.error("خطأ إعداد: أضف DISCORD_TOKEN و OWNER_ID إلى Replit Secrets.");
  process.exit(1);
}

const DATA_DIR = path.join(__dirname, "..", "data");
const STORE_PATH = path.join(DATA_DIR, "store.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultStore = {
  guilds: {},
  logs: [],
  campaigns: [],
  botDefaults: {},
  botStartupSettings: {},
  botPresence: { status: "online", activity: "Vero" }
};
let store;
try {
  store = fs.existsSync(STORE_PATH)
    ? { ...defaultStore, ...JSON.parse(fs.readFileSync(STORE_PATH, "utf8")) }
    : structuredClone(defaultStore);
} catch (error) {
  console.error("تعذرت قراءة data/store.json. أصلح الملف أو احذفه لإنشاء إعدادات جديدة.", error);
  process.exit(1);
}
store.botDefaults ||= {};
store.botStartupSettings ||= {};
store.campaigns ||= [];
store.botPresence ||= { ...defaultStore.botPresence };
store.botPresence.status ||= "online";
store.botPresence.activity ||= "Vero";

function saveStore() {
  const temporaryPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(store, null, 2), "utf8");
  fs.renameSync(temporaryPath, STORE_PATH);
}
function guildConfig(guildId) {
  if (!store.guilds[guildId]) {
    store.guilds[guildId] = {
      prefix: process.env.DEFAULT_PREFIX || "!",
      accessMode: true,
      allowedUsers: [],
      allowedRoles: []
    };
    saveStore();
  }
  return store.guilds[guildId];
}
function hasAccess(member, userId, config) {
  if (userId === OWNER_ID) return true;
  if (config.accessMode) {
    return config.allowedUsers.includes(userId) ||
      member.roles.cache.some(role => config.allowedRoles.includes(role.id));
  }
  return Boolean(member.permissions.has(PermissionsBitField.Flags.ManageGuild));
}
function isOwner(userId) {
  return userId === OWNER_ID;
}
function clampText(value, max) {
  return String(value || "").slice(0, max);
}
function safeUrl(value) {
  if (!value) return null;
  try {
    const u = new URL(value);
    return ["https:", "http:"].includes(u.protocol) ? u.toString() : null;
  } catch {
    return null;
  }
}
function chunkIds(value) {
  return [...new Set(String(value || "").split(/[,\s]+/).map(x => x.trim()).filter(x => /^\d{15,22}$/.test(x)))];
}
function panelRows(session) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:compose:${session.id}`).setLabel("Compose").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`bc:recipients:${session.id}`).setLabel("Recipients").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`bc:preview:${session.id}`).setLabel("Preview").setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:send:${session.id}`).setLabel("Send").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel").setStyle(ButtonStyle.Danger),
    )
  ];
}
function panelEmbed(session) {
  const audience = session.audience.type === "everyone" ? "Everyone" :
    session.audience.type === "role" ? `Role ID: ${session.audience.roleId || "not set"}` :
    `Selected members: ${session.audience.userIds.length}`;
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("لوحة الإعلانات الخاصة")
    .setDescription("جهّز الرسالة وحدّد الجمهور، ثم عاينها قبل الإرسال.")
    .addFields(
      { name: "Content", value: session.content.title ? "Configured" : "Not configured", inline: true },
      { name: "Format", value: session.content.mode === "text" ? "Plain text" : "Embed", inline: true },
      { name: "Recipients", value: audience, inline: true },
    )
    .setFooter({ text: "الإرسال يكون عبر الخاص، وقد ترفض Discord بعض الرسائل." });
}
function makePreview(session, recipientId = null) {
  const personalize = value => recipientId
    ? value.replaceAll("[User]", `<@${recipientId}>`)
    : value;
  if (session.content.mode === "text") {
    let text = personalize(session.content.body || "(لا يوجد نص بعد)");
    if (session.content.title) text = `**${personalize(session.content.title)}**\n${text}`;
    if (session.content.imageUrl) text += `\n${session.content.imageUrl}`;
    const payload = { content: text.slice(0, 2000), embeds: [] };
    if (recipientId && text.includes(`<@${recipientId}>`)) {
      payload.allowedMentions = { users: [recipientId] };
    }
    return payload;
  }
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(personalize(session.content.title || "إعلان"))
    .setDescription(personalize(session.content.body || "لا يوجد نص بعد"));
  if (session.content.imageUrl) embed.setImage(session.content.imageUrl);
  return { content: null, embeds: [embed] };
}
function createSession(guildId, userId) {
  const id = Math.random().toString(36).slice(2, 9);
  const session = {
    id, guildId, userId, createdAt: Date.now(),
    content: { title: "", body: "", imageUrl: "", mode: "embed" },
    audience: { type: "everyone", roleId: "", userIds: [] },
    cancelled: false, running: false
  };
  sessions.set(id, session);
  return session;
}
const sessions = new Map();
const voicePanelSessions = new Map();

const botIntents = [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages
];
function createBotClient() {
  return new Client({
    intents: botIntents,
    partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User]
  });
}
const client = createBotClient();
const childBotTokenNames = ["DISCORD_TOKEN_2", "DISCORD_TOKEN_3", "DISCORD_TOKEN_4", "DISCORD_TOKEN_5"];
const childBotSlots = childBotTokenNames.map(tokenName => ({
  tokenName,
  token: process.env[tokenName],
  client: process.env[tokenName] ? createBotClient() : null
}));
const botSlots = [{ tokenName: "DISCORD_TOKEN", token: TOKEN, client }, ...childBotSlots];
const allBotClients = botSlots.map(slot => slot.client).filter(Boolean);

client.once("ready", () => {
  console.log(`تم تسجيل الدخول بنجاح باسم ${client.user.tag}`);
  console.log("اكتب !help للأوامر، ووجّه Come أو Go إلى البوت المطلوب.");
  client.user.setPresence({
    status: store.botPresence.status,
    activities: [{ name: store.botPresence.activity, type: ActivityType.Playing }]
  });
});
for (const slot of childBotSlots) {
  if (!slot.client) {
    console.warn(`${slot.tokenName} is not configured; that child bot is disabled.`);
    continue;
  }
  slot.client.once("ready", () => {
    console.log(`Child bot ready: ${slot.client.user.tag}`);
    slot.client.user.setPresence({
      status: store.botPresence.status,
      activities: [{ name: store.botPresence.activity, type: ActivityType.Playing }]
    });
  });
  slot.client.on("messageCreate", message => {
    handleChildVoiceMessage(slot.client, message).catch(error => {
      console.error(`Voice command failed for ${slot.tokenName}:`, error);
    });
  });
  slot.client.on("error", error => console.error(`Discord client error (${slot.tokenName}):`, error));
}

function captureDefaultBotProfile() {
  if (store.botDefaults.username) return store.botDefaults;
  const avatarIsAnimated = client.user.avatar?.startsWith("a_");
  store.botDefaults = {
    username: client.user.username,
    avatarUrl: client.user.avatar
      ? client.user.avatarURL({ extension: avatarIsAnimated ? "gif" : "png", size: 1024 })
      : null,
    bannerUrl: client.user.banner
      ? client.user.bannerURL({ extension: client.user.banner.startsWith("a_") ? "gif" : "png", size: 1024 })
      : null
  };
  saveStore();
  return store.botDefaults;
}

async function fetchImageData(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(20_000) });
  if (!response.ok) throw new Error(`تعذر تحميل الصورة (HTTP ${response.status}).`);
  const contentType = (response.headers.get("content-type") || "").split(";")[0].toLowerCase();
  if (!["image/png", "image/jpeg", "image/gif", "image/webp"].includes(contentType)) {
    throw new Error("استخدم صورة PNG أو JPG أو GIF أو WebP.");
  }
  const maxBytes = 6 * 1024 * 1024;
  const declaredSize = Number(response.headers.get("content-length"));
  if (declaredSize > maxBytes) throw new Error("حجم الصورة يجب ألا يتجاوز 6 ميغابايت.");
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > maxBytes) throw new Error("حجم الصورة يجب ألا يتجاوز 6 ميغابايت.");
  return `data:${contentType};base64,${bytes.toString("base64")}`;
}

async function getCommandImage(message) {
  let sourceMessage = message;
  let attachment = message.attachments.first();
  if (!attachment && message.reference?.messageId) {
    sourceMessage = await message.fetchReference();
    attachment = sourceMessage.attachments.first();
  }
  if (!attachment) {
    throw new Error("أرفق صورة مع الأمر أو ردّ على رسالة تحتوي على صورة.");
  }
  if (attachment.size > 6 * 1024 * 1024) {
    throw new Error("حجم الصورة يجب ألا يتجاوز 6 ميغابايت.");
  }
  return fetchImageData(attachment.url);
}

async function handleVoiceCommand(message, command, botClient = client) {
  const memberChannel = message.member?.voice?.channel;
  if (!memberChannel) {
    return message.reply("اتصل بالقناة الصوتية التي تريد استخدامها أولاً، ثم أرسل الأمر في محادثتها.");
  }
  const config = guildConfig(message.guild.id);
  if (!hasAccess(message.member, message.author.id, config)) {
    return message.reply("ليس لديك صلاحية نقل البوت إلى القنوات الصوتية.");
  }

  const group = botClient.user.id;
  const connection = getVoiceConnection(message.guild.id, group);
  const botMember = message.guild.members.me || await message.guild.members.fetch(botClient.user.id);
  if (command === "go") {
    if (!connection) return message.reply(`${botClient.user.username} غير متصل بقناة صوتية حالياً.`);
    if (connection.joinConfig.channelId !== memberChannel.id) {
      return message.reply("أرسل Go من القناة الصوتية التي يتصل بها البوت.");
    }
    connection.destroy();
    return message.reply(`غادر **${botClient.user.username}** القناة الصوتية **${memberChannel.name}**.`);
  }

  if (connection?.joinConfig.channelId === memberChannel.id) {
    return message.reply(`**${botClient.user.username}** موجود بالفعل في **${memberChannel.name}**.`);
  }
  const permissions = memberChannel.permissionsFor(botMember);
  if (!permissions?.has([PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect])) {
    return message.reply(`يحتاج **${botClient.user.username}** إلى صلاحيتي View Channel و Connect في هذه القناة.`);
  }

  connection?.destroy();
  let nextConnection;
  try {
    nextConnection = joinVoiceChannel({
      channelId: memberChannel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator,
      group,
      selfDeaf: true,
      selfMute: false
    });
    await entersState(nextConnection, VoiceConnectionStatus.Ready, 20_000);
    return message.reply(`دخل **${botClient.user.username}** القناة **${memberChannel.name}** وهو صامت. اكتب Go من هذه القناة ليغادر.`);
  } catch (error) {
    nextConnection?.destroy();
    console.error(`Voice connection failed for ${botClient.user.tag}:`, error);
    return message.reply(`تعذر اتصال **${botClient.user.username}** بالقناة. تحقق من صلاحياته وحاول مرة أخرى.`);
  }
}

async function handleChildVoiceMessage(botClient, message) {
  if (!message.guild || message.author.bot || !botClient.user) return;
  const voiceCommand = message.content.match(
    new RegExp(`^(come|go)\\s+<@!?${botClient.user.id}>\\s*$`, "i")
  );
  if (!voiceCommand) return;
  return handleVoiceCommand(message, voiceCommand[1].toLowerCase(), botClient);
}

function voicePanelEmbed(session) {
  const selected = new Set(session.selectedBotIds);
  const rows = botSlots.map((slot, index) => {
    const botClient = slot.client;
    const label = botClient?.user?.tag || (index === 0 ? "Main bot" : `Child bot ${index}`);
    if (!slot.token) return `• ${label}: secret missing`;
    if (!botClient?.isReady()) return `• ${label}: offline/connecting`;
    if (!botClient.guilds.cache.has(session.guildId)) return `• ${label}: not in this server`;
    const connection = getVoiceConnection(session.guildId, botClient.user.id);
    const channelId = connection?.joinConfig.channelId;
    const channel = channelId ? client.guilds.cache.get(session.guildId)?.channels.cache.get(channelId) : null;
    return `• ${selected.has(botClient.user.id) ? "☑" : "☐"} ${label}: ${channel ? channel.name : channelId ? `connected (${channelId})` : "not connected"}`;
  });
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("Voice bot control panel")
    .setDescription([
      "Choose accounts in the menu, connect yourself to a voice channel, then bind selected bots or all bots.",
      ...rows
    ].join("\n"));
}

function voicePanelComponents(session) {
  const readyClients = allBotClients.filter(botClient => botClient.isReady());
  const selectBots = new StringSelectMenuBuilder()
    .setCustomId(`voicepanel:select:${session.id}`)
    .setPlaceholder("Choose voice bots")
    .setMinValues(1)
    .setMaxValues(Math.max(1, readyClients.length))
    .addOptions(readyClients.map(botClient => ({
      label: botClient.user.username.slice(0, 100),
      value: botClient.user.id,
      default: session.selectedBotIds.includes(botClient.user.id)
    })));
  return [
    new ActionRowBuilder().addComponents(selectBots),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`voicepanel:come-selected:${session.id}`).setLabel("Join selected").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`voicepanel:go-selected:${session.id}`).setLabel("Leave selected").setStyle(ButtonStyle.Secondary)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`voicepanel:come-all:${session.id}`).setLabel("Join all five").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`voicepanel:go-all:${session.id}`).setLabel("Leave all here").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`voicepanel:refresh:${session.id}`).setLabel("Refresh").setStyle(ButtonStyle.Secondary)
    )
  ];
}

async function joinBotToVoiceChannel(botClient, guildId, channelId) {
  const guild = botClient.guilds.cache.get(guildId);
  if (!guild) throw new Error("هذا البوت غير موجود في السيرفر.");
  const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isVoiceBased()) throw new Error("القناة الصوتية غير متاحة لهذا البوت.");
  const botMember = guild.members.me || await guild.members.fetch(botClient.user.id);
  const permissions = channel.permissionsFor(botMember);
  if (!permissions?.has([PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect])) {
    throw new Error("لا يملك هذا البوت صلاحيتي View Channel و Connect.");
  }

  const group = botClient.user.id;
  const existing = getVoiceConnection(guildId, group);
  if (existing?.joinConfig.channelId === channelId) {
    return `**${botClient.user.username}** موجود بالفعل في **${channel.name}**.`;
  }
  existing?.destroy();
  let connection;
  try {
    connection = joinVoiceChannel({
      channelId,
      guildId,
      adapterCreator: guild.voiceAdapterCreator,
      group,
      selfDeaf: true,
      selfMute: false
    });
    await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
    return `دخل **${botClient.user.username}** إلى **${channel.name}**.`;
  } catch (error) {
    connection?.destroy();
    throw error;
  }
}

async function leaveBotVoiceChannel(botClient, guildId, memberChannelId) {
  const connection = getVoiceConnection(guildId, botClient.user.id);
  if (!connection) return `**${botClient.user.username}** غير متصل بالصوت.`;
  if (connection.joinConfig.channelId !== memberChannelId) {
    throw new Error(`يجب أن تكون في قناة **${botClient.user.username}** الصوتية لمغادرته.`);
  }
  connection.destroy();
  return `غادر **${botClient.user.username}** القناة الصوتية.`;
}

async function handleMentionCommand(message, command, args) {
  const config = guildConfig(message.guild.id);
  if (command === "come" || command === "go") {
    return handleVoiceCommand(message, command);
  }

  if (command === "help" || command === "settings") {
    return message.reply([
      "**إعدادات البوت (للمالك فقط):**",
      "`@BotUser setname الاسم` — تغيير لقب البوت في هذا السيرفر",
      "`@BotUser setuser الاسم` — تغيير اسم مستخدم البوت العام",
      "`@BotUser setavatar` / `@BotUser setbanner` — أرفق صورة أو رد على رسالة صورة",
      "`@BotUser setstatus online|idle|dnd|invisible` — تغيير حالة الظهور",
      "`@BotUser setactivity اسم` — تغيير النشاط (مثل Vero)",
      "`@BotUser setdefault` — استعادة الأسماء وصور الملف الأصلية",
      "`Come @BotUser` — دخوله قناتك الصوتية",
      "`Go @BotUser` — إخراجه من القناة نفسها",
      "يمكن تشغيل كل حساب بوت في قناة واحدة لكل سيرفر؛ استخدم منشن الحساب المطلوب، ويمكن ضم عدة حسابات إلى القناة نفسها."
    ].join("\n"));
  }

  const isProfileCommand = ["setname", "setuser", "setavatar", "setbanner", "setstatus", "setactivity", "setdefault"].includes(command);
  if (!isProfileCommand) return;
  if (!isOwner(message.author.id)) {
    return message.reply("إعدادات الملف الشخصي متاحة لمالك البوت فقط.");
  }

  if (command === "setname") {
    const name = args.join(" ").trim();
    if (!name || name.length > 32) return message.reply("استخدم: `@BotUser setname اسم من 1 إلى 32 حرفاً`.");
    const botMember = message.guild.members.me || await message.guild.members.fetch(client.user.id);
    config.botSettings ||= {};
    if (!Object.hasOwn(config.botSettings, "defaultNickname")) {
      config.botSettings.defaultNickname = botMember.nickname || null;
    }
    try {
      await botMember.setNickname(name);
      saveStore();
      return message.reply(`تم تغيير لقب البوت في هذا السيرفر إلى **${name}**.`);
    } catch (error) {
      console.error("Could not update bot nickname:", error);
      return message.reply("تعذر تغيير اللقب. تحقق من صلاحية Manage Nicknames وترتيب رتب البوت.");
    }
  }

  if (command === "setuser") {
    const username = args.join(" ").trim();
    if (!username || username.length < 2 || username.length > 32) {
      return message.reply("استخدم: `@BotUser setuser اسم من 2 إلى 32 حرفاً`.");
    }
    try {
      captureDefaultBotProfile();
      await client.rest.patch(Routes.user(), { body: { username } });
      return message.reply(`تم تغيير اسم مستخدم البوت العام إلى **${username}**.`);
    } catch (error) {
      console.error("Could not update bot username:", error);
      return message.reply("تعذر تغيير اسم المستخدم. قد تفرض Discord قيوداً على الاسم أو تتطلب تغييره من Developer Portal.");
    }
  }

  if (command === "setavatar" || command === "setbanner") {
    try {
      captureDefaultBotProfile();
      const image = await getCommandImage(message);
      await client.rest.patch(Routes.user(), {
        body: { [command === "setavatar" ? "avatar" : "banner"]: image }
      });
      return message.reply(`تم تحديث ${command === "setavatar" ? "صورة البوت" : "غلاف البوت"} في كل السيرفرات.`);
    } catch (error) {
      console.error(`Could not update bot ${command}:`, error);
      return message.reply(`تعذر تحديث الصورة: ${error.message || "تحقق من صيغة الصورة وحاول مرة أخرى."}`);
    }
  }

  if (command === "setstatus") {
    const status = (args[0] || "").toLowerCase();
    if (!["online", "idle", "dnd", "invisible"].includes(status)) {
      return message.reply("استخدم: `@BotUser setstatus online|idle|dnd|invisible`.");
    }
    store.botPresence.status = status;
    saveStore();
    client.user.setStatus(status);
    return message.reply(`تم تغيير حالة ظهور البوت إلى **${status}**.`);
  }

  if (command === "setactivity") {
    const activity = args.join(" ").trim();
    if (!activity || activity.length > 128) return message.reply("استخدم: `@BotUser setactivity اسم النشاط`.");
    store.botPresence.activity = activity;
    saveStore();
    client.user.setActivity(activity, { type: ActivityType.Playing });
    return message.reply(`تم تغيير النشاط إلى **Playing ${activity}**.`);
  }

  if (command === "setdefault") {
    const defaults = captureDefaultBotProfile();
    let nicknameRestored = 0;
    let nicknameFailed = 0;
    for (const guild of client.guilds.cache.values()) {
      const guildSettings = guildConfig(guild.id).botSettings;
      if (!guildSettings || !Object.hasOwn(guildSettings, "defaultNickname")) continue;
      try {
        const botMember = guild.members.me || await guild.members.fetch(client.user.id);
        await botMember.setNickname(guildSettings.defaultNickname);
        delete guildConfig(guild.id).botSettings.defaultNickname;
        nicknameRestored++;
      } catch (error) {
        nicknameFailed++;
        console.error(`Could not restore bot nickname in guild ${guild.id}:`, error);
      }
    }
    try {
      const [avatar, banner] = await Promise.all([
        defaults.avatarUrl ? fetchImageData(defaults.avatarUrl) : null,
        defaults.bannerUrl ? fetchImageData(defaults.bannerUrl) : null
      ]);
      await client.rest.patch(Routes.user(), {
        body: { username: defaults.username, avatar, banner }
      });
      saveStore();
      return message.reply(`تمت استعادة اسم المستخدم والصور الأصلية، وإعادة الألقاب الأصلية في ${nicknameRestored} سيرفر. فشل استرجاع الألقاب في ${nicknameFailed} سيرفر.`);
    } catch (error) {
      saveStore();
      console.error("Could not restore default bot profile:", error);
      return message.reply(`تمت معالجة الألقاب في ${nicknameRestored} سيرفر، لكن تعذر استعادة الملف العام: ${error.message || "تحقق من إعدادات Discord."}`);
    }
  }
}

async function fetchRecipients(guild, audience) {
  if (audience.type === "everyone") {
    await guild.members.fetch();
    return [...guild.members.cache.values()].filter(m => !m.user.bot);
  }
  if (audience.type === "role") {
    if (!/^\d{15,22}$/.test(audience.roleId)) throw new Error("رقم الرتبة غير صحيح.");
    const role = await guild.roles.fetch(audience.roleId).catch(() => null);
    if (!role) throw new Error("لم أجد هذه الرتبة في السيرفر.");
    await guild.members.fetch();
    return [...role.members.values()].filter(m => !m.user.bot);
  }
  const members = [];
  for (const id of audience.userIds) {
    const member = await guild.members.fetch(id).catch(() => null);
    if (member && !member.user.bot) members.push(member);
  }
  return [...new Map(members.map(m => [m.id, m])).values()];
}

async function runBroadcast(interaction, session) {
  if (session.running) {
    return interaction.reply({ content: "هذه الحملة قيد التنفيذ بالفعل.", ephemeral: true });
  }
  if (!session.content.body.trim()) {
    return interaction.reply({ content: "أضف نص الرسالة أولاً باستخدام Compose.", ephemeral: true });
  }
  if (session.audience.type === "role" && !session.audience.roleId) {
    return interaction.reply({ content: "حدّد رقم الرتبة من Recipients أولاً.", ephemeral: true });
  }
  if (session.audience.type === "members" && session.audience.userIds.length === 0) {
    return interaction.reply({ content: "أضف أرقام الأعضاء من Recipients أولاً.", ephemeral: true });
  }
  session.running = true;
  await interaction.reply({
    content: "بدأت الحملة. يمكنك متابعة التقدم أو إيقاف الإرسال من الزر أدناه.",
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel Campaign").setStyle(ButtonStyle.Danger)
    )],
    ephemeral: true
  });
  let progressMessage = await interaction.fetchReply().catch(() => null);

  let recipients;
  try {
    recipients = await fetchRecipients(interaction.guild, session.audience);
  } catch (error) {
    session.running = false;
    return interaction.followUp({ content: `تعذر تجهيز المستلمين: ${error.message}`, ephemeral: true });
  }

  let sent = 0, failed = 0, skipped = 0;
  const failureExamples = [];
  const startedAt = new Date().toISOString();
  const progressLock = { pending: Promise.resolve() };
  const updateProgress = async () => {
    if (!progressMessage) return;
    // Serialize edits so concurrent sender workers do not race each other.
    progressLock.pending = progressLock.pending.then(async () => {
      const progressEmbed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(session.cancelled ? "جارٍ إيقاف الحملة..." : "تقدم الحملة")
        .setDescription(`المستلمون: ${recipients.length}\nتم الإرسال: ${sent}\nفشل الإرسال: ${failed}\nتم تخطيهم: ${skipped}`);
      await progressMessage.edit({ embeds: [progressEmbed], content: null }).catch(() => {});
    });
    await progressLock.pending;
  };

  // Share recipients between the main bot and every configured child bot that is online.
  // Each sender processes its own queue sequentially; discord.js still handles API rate limits.
  const activeSenders = botSlots.filter(slot =>
    slot.client?.isReady() && slot.client.guilds.cache.has(interaction.guildId)
  );
  if (!activeSenders.length) {
    session.running = false;
    return interaction.followUp({ content: "لا توجد حسابات بوت متصلة لإرسال الحملة.", ephemeral: true });
  }
  const queues = activeSenders.map(() => []);
  recipients.forEach((member, index) => queues[index % activeSenders.length].push(member));
  const totalAttempts = recipients.length;
  let processed = 0;
  await updateProgress();

  await Promise.all(activeSenders.map(async (slot, senderIndex) => {
    const queue = queues[senderIndex];
    for (const member of queue) {
      if (session.cancelled) {
        skipped++;
        processed++;
        continue;
      }
      try {
        // Fetch the recipient through the sender account, then send using that account's DM channel.
        const senderClient = slot.client;
        const recipientUser = await senderClient.users.fetch(member.id);
        const dmChannel = await recipientUser.createDM();
        await dmChannel.send(makePreview(session, member.id));
        sent++;
      } catch (error) {
        failed++;
        if (failureExamples.length < 8) {
          failureExamples.push(`${member.user.tag} (${member.id}) via ${slot.client.user?.username || slot.tokenName}: ${String(error.message || "تعذر الإرسال").slice(0, 100)}`);
        }
      }
      processed++;
      if (processed % 5 === 0 || processed === totalAttempts) await updateProgress();
      // Per-sender pacing; the Discord library's own rate-limit handling remains enabled.
      if (processed < totalAttempts && !session.cancelled) {
        await new Promise(resolve => setTimeout(resolve, 1200));
      }
    }
  }));
  await updateProgress();

  session.running = false;
  const log = {
    id: `${Date.now()}`,
    guildId: interaction.guildId,
    initiatedBy: interaction.user.id,
    startedAt,
    completedAt: new Date().toISOString(),
    audience: session.audience.type,
    attempted: sent + failed,
    sent, failed, skipped,
    cancelled: session.cancelled
  };
  store.logs.push(log);
  if (store.logs.length > 200) store.logs = store.logs.slice(-200);
  saveStore();

  const report = new EmbedBuilder()
    .setColor(session.cancelled ? 0xFAA61A : 0x57F287)
    .setTitle(session.cancelled ? "تقرير الحملة (تم الإلغاء)" : "تقرير الحملة")
    .addFields(
      { name: "المستلمون المحددون", value: String(recipients.length), inline: true },
      { name: "تم الإرسال", value: String(sent), inline: true },
      { name: "فشل الإرسال", value: String(failed), inline: true },
      { name: "تم تخطيهم", value: String(skipped), inline: true }
    );
  if (failureExamples.length) {
    report.addFields({ name: "نماذج من حالات الفشل", value: failureExamples.join("\n").slice(0, 1024) });
  }
  report.setFooter({ text: "فشل DM لا يعني بالضرورة أن الحساب غير موجود؛ قد تكون الخصوصية أو قيود Discord هي السبب." });
  await interaction.followUp({ embeds: [report], ephemeral: true });
  sessions.delete(session.id);
}

client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot || !client.user) return;
  const botId = client.user.id;
  const leadingVoiceCommand = message.content.match(new RegExp(`^(come|go)\\s+<@!?${botId}>\\s*$`, "i"));
  if (leadingVoiceCommand) {
    try {
      await handleMentionCommand(message, leadingVoiceCommand[1].toLowerCase(), []);
    } catch (error) {
      console.error("Voice command failed:", error);
      await message.reply("تعذر تنفيذ الأمر. تحقق من صلاحيات البوت وحاول مرة أخرى.");
    }
    return;
  }

  const mentionCommand = message.content.match(new RegExp(`^<@!?${botId}>\\s+([\\s\\S]+)$`));
  if (mentionCommand) {
    const parts = mentionCommand[1].trim().split(/\s+/);
    const command = (parts.shift() || "").toLowerCase();
    try {
      await handleMentionCommand(message, command, parts);
    } catch (error) {
      console.error("Bot settings command failed:", error);
      await message.reply("تعذر تنفيذ الأمر. تحقق من المدخلات وصلاحيات البوت، ثم حاول مرة أخرى.");
    }
    return;
  }

  const config = guildConfig(message.guild.id);
  const prefix = config.prefix || "!";
  if (!message.content.startsWith(prefix)) return;

  const raw = message.content.slice(prefix.length).trim();
  const parts = raw.split(/\s+/);
  const command = (parts.shift() || "").toLowerCase();
  const args = parts;

  if (command === "help") {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle("مساعدة بوت الإعلانات")
      .setDescription([
        `\`${prefix}broadcast\` — فتح لوحة الإعلانات`,
        `\`${prefix}bots\` — حالة حسابات البوتات والصوت`,
        `\`${prefix}voicepanel\` — لوحة ضمّ البوتات للقناة الصوتية أو إخراجها`,
        "`@BotUser settings` — إعداد الاسم والصورة والحالة والنشاط",
        `\`${prefix}setprefix ?\` — تغيير البادئة`,
        `\`${prefix}access user add USER_ID\` — السماح لمستخدم`,
        `\`${prefix}access user remove USER_ID\` — إزالة مستخدم`,
        `\`${prefix}access role add ROLE_ID\` — السماح لرتبة`,
        `\`${prefix}access role remove ROLE_ID\` — إزالة رتبة`,
        `\`${prefix}access list\` — عرض السماح`,
        `\`${prefix}access mode on/off\` — تشغيل/إيقاف قائمة السماح`
      ].join("\n"));
    return message.reply({ embeds: [embed] });
  }

  if (command === "bots") {
    if (!hasAccess(message.member, message.author.id, config)) {
      return message.reply("ليس لديك صلاحية عرض حالة حسابات البوتات.");
    }
    const statuses = botSlots.map((slot, index) => {
      const label = slot.client?.user?.tag || (index === 0 ? "Main bot" : `Child bot ${index}`);
      const status = !slot.token
        ? "secret not configured"
        : slot.client?.isReady()
          ? "online"
          : "connecting/offline";
      return `• ${label}: ${status}`;
    });
    return message.reply({
      embeds: [new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle("حالة البوتات")
        .setDescription(statuses.join("\n"))
        .setFooter({ text: "اكتب Come @BotUser في القناة الصوتية لضم حساب محدد، وGo @BotUser لمغادرته." })]
    });
  }

  if (command === "voicepanel") {
    if (!hasAccess(message.member, message.author.id, config)) {
      return message.reply("ليس لديك صلاحية التحكم باتصالات البوتات الصوتية.");
    }
    const id = Math.random().toString(36).slice(2, 10);
    const readyIds = allBotClients.filter(botClient => botClient.isReady()).map(botClient => botClient.user.id);
    const session = {
      id,
      guildId: message.guild.id,
      userId: message.author.id,
      selectedBotIds: readyIds,
      createdAt: Date.now()
    };
    voicePanelSessions.set(id, session);
    return message.reply({
      embeds: [voicePanelEmbed(session)],
      components: voicePanelComponents(session)
    });
  }

  if (command === "setprefix") {
    if (!isOwner(message.author.id) && !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply("هذا الأمر للمالك أو لمن لديه صلاحية Manage Server.");
    }
    const next = args[0];
    if (!next || next.length > 5 || /\s/.test(next)) {
      return message.reply(`استخدم: \`${prefix}setprefix ?\` (بادئة من 1 إلى 5 أحرف دون مسافات).`);
    }
    config.prefix = next;
    saveStore();
    return message.reply(`تم تغيير البادئة إلى \`${next}\`.`);
  }

  if (command === "access") {
    if (!isOwner(message.author.id)) return message.reply("هذا الأمر متاح لمالك البوت فقط.");
    const [kind, action, id] = args;
    if (kind === "mode" && ["on", "off"].includes(action)) {
      config.accessMode = action === "on";
      saveStore();
      return message.reply(config.accessMode
        ? "تم تفعيل قائمة السماح. المالك مسموح دائماً."
        : "تم إيقاف قائمة السماح. المالك وأصحاب Manage Server يستطيعون استخدام لوحة الإعلانات.");
    }
    if (kind === "list") {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle("قائمة السماح")
          .addFields(
            { name: "Users", value: config.allowedUsers.join("\n") || "لا يوجد", inline: true },
            { name: "Roles", value: config.allowedRoles.join("\n") || "لا يوجد", inline: true },
            { name: "Mode", value: config.accessMode ? "On" : "Off", inline: true }
          )]
      });
    }
    if (!["user", "role"].includes(kind) || !["add", "remove"].includes(action) || !/^\d{15,22}$/.test(id || "")) {
      return message.reply(`الاستخدام:\n\`${prefix}access user add USER_ID\`\n\`${prefix}access user remove USER_ID\`\n\`${prefix}access role add ROLE_ID\`\n\`${prefix}access role remove ROLE_ID\`\n\`${prefix}access list\`\n\`${prefix}access mode on/off\``);
    }
    const list = kind === "user" ? config.allowedUsers : config.allowedRoles;
    if (action === "add" && !list.includes(id)) list.push(id);
    if (action === "remove") {
      const index = list.indexOf(id);
      if (index >= 0) list.splice(index, 1);
    }
    saveStore();
    return message.reply(`${action === "add" ? "تمت الإضافة إلى" : "تمت الإزالة من"} قائمة ${kind === "user" ? "المستخدمين" : "الرتب"}.`);
  }

  if (command === "broadcast") {
    if (!hasAccess(message.member, message.author.id, config)) {
      return message.reply("ليس لديك صلاحية استخدام لوحة الإعلانات.");
    }
    const session = createSession(message.guild.id, message.author.id);
    return message.reply({ embeds: [panelEmbed(session)], components: panelRows(session) });
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.inGuild() || !interaction.guild) return;
  const customId = interaction.customId || "";
  if (customId.startsWith("voicepanel:")) {
    const [, action, panelId] = customId.split(":");
    const panel = voicePanelSessions.get(panelId);
    if (!panel || panel.guildId !== interaction.guildId || Date.now() - panel.createdAt > 2 * 60 * 60 * 1000) {
      voicePanelSessions.delete(panelId);
      return interaction.reply({ content: "انتهت صلاحية لوحة الصوت. افتحها مجدداً باستخدام !voicepanel.", ephemeral: true });
    }
    if (panel.userId !== interaction.user.id && interaction.user.id !== OWNER_ID) {
      return interaction.reply({ content: "لوحة الصوت هذه تخص مستخدماً آخر.", ephemeral: true });
    }
    if (action === "select" && interaction.isStringSelectMenu()) {
      const readyIds = new Set(allBotClients.filter(botClient => botClient.isReady()).map(botClient => botClient.user.id));
      panel.selectedBotIds = interaction.values.filter(id => readyIds.has(id));
      if (!panel.selectedBotIds.length) {
        return interaction.reply({ content: "اختر بوتاً واحداً على الأقل.", ephemeral: true });
      }
      return interaction.update({
        content: null,
        embeds: [voicePanelEmbed(panel)],
        components: voicePanelComponents(panel)
      });
    }
    if (!interaction.isButton()) return;
    if (action === "refresh") {
      return interaction.update({
        content: null,
        embeds: [voicePanelEmbed(panel)],
        components: voicePanelComponents(panel)
      });
    }
    if (!["come-selected", "go-selected", "come-all", "go-all"].includes(action)) return;

    await interaction.deferUpdate();
    try {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const config = guildConfig(interaction.guildId);
      if (!hasAccess(member, interaction.user.id, config)) {
        return interaction.editReply({ content: "ليس لديك صلاحية التحكم باتصالات البوتات الصوتية." });
      }
      const memberChannelId = member.voice.channelId;
      if (!memberChannelId) {
        return interaction.editReply({
          content: "اتصل بالقناة الصوتية التي تريد استخدامها، ثم استخدم اللوحة.",
          embeds: [voicePanelEmbed(panel)],
          components: voicePanelComponents(panel)
        });
      }
      const useAll = action.endsWith("-all");
      const isCome = action.startsWith("come-");
      const targetSlots = (useAll ? botSlots : botSlots.filter(slot =>
        slot.client && panel.selectedBotIds.includes(slot.client.user?.id)
      ));
      const targets = targetSlots.filter(slot => slot.client?.isReady());
      const unavailable = targetSlots
        .filter(slot => !slot.client?.isReady())
        .map(slot => `• ${slot.tokenName}: offline or not configured`);
      const results = await Promise.all(targets.map(async slot => {
        const botClient = slot.client;
        try {
          return isCome
            ? await joinBotToVoiceChannel(botClient, interaction.guildId, memberChannelId)
            : await leaveBotVoiceChannel(botClient, interaction.guildId, memberChannelId);
        } catch (error) {
          return `تعذر تنفيذ الأمر على **${botClient.user.username}**: ${error.message || "خطأ غير معروف"}`;
        }
      }));
      const summaryLines = [...results, ...unavailable];
      const summary = summaryLines.length
        ? summaryLines.join("\n").slice(0, 1800)
        : "لا توجد حسابات بوت متصلة حالياً.";
      return interaction.editReply({
        content: summary,
        embeds: [voicePanelEmbed(panel)],
        components: voicePanelComponents(panel)
      });
    } catch (error) {
      console.error("Voice panel action failed:", error);
      return interaction.editReply({
        content: "تعذر تنفيذ الإجراء. تحقق من حالة البوتات وصلاحيات القناة.",
        embeds: [voicePanelEmbed(panel)],
        components: voicePanelComponents(panel)
      });
    }
  }
  if (!customId.startsWith("bc:")) return;
  const [, action, sessionId] = customId.split(":");
  const session = sessions.get(sessionId);
  if (!session || session.guildId !== interaction.guildId) {
    return interaction.reply({ content: "انتهت صلاحية هذه اللوحة. نفّذ أمر broadcast من جديد.", ephemeral: true });
  }
  if (session.userId !== interaction.user.id && interaction.user.id !== OWNER_ID) {
    return interaction.reply({ content: "هذه اللوحة تخص مستخدماً آخر.", ephemeral: true });
  }
  if (session.cancelled) return interaction.reply({ content: "تم إلغاء هذه المسودة.", ephemeral: true });

  if (action === "compose") {
    const modal = new ModalBuilder().setCustomId(`bcmodal:compose:${session.id}`).setTitle("Compose broadcast");
    const title = new TextInputBuilder().setCustomId("title").setLabel("العنوان (اختياري)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(256).setValue(session.content.title || "");
    const body = new TextInputBuilder().setCustomId("body").setLabel("نص الرسالة ([User] = المستلم)").setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setValue(session.content.body || "");
    const image = new TextInputBuilder().setCustomId("image").setLabel("رابط صورة HTTP/HTTPS (اختياري)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(session.content.imageUrl || "");
    const mode = new TextInputBuilder().setCustomId("mode").setLabel("النوع: embed أو text").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(10).setValue(session.content.mode || "embed");
    modal.addComponents(
      new ActionRowBuilder().addComponents(title),
      new ActionRowBuilder().addComponents(body),
      new ActionRowBuilder().addComponents(image),
      new ActionRowBuilder().addComponents(mode)
    );
    return interaction.showModal(modal);
  }

  if (action === "recipients") {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`bc:audience:${session.id}`)
      .setPlaceholder("اختر الجمهور")
      .addOptions(
        { label: "Everyone", description: "كل الأعضاء غير البوتات", value: "everyone" },
        { label: "Role", description: "أعضاء رتبة محددة", value: "role" },
        { label: "Selected members", description: "حسابات محددة بأرقام المستخدمين", value: "members" }
      );
    return interaction.reply({
      content: `الجمهور الحالي: ${session.audience.type}. بعد الاختيار ستظهر لك نافذة لإدخال رقم الرتبة أو أرقام المستخدمين عند الحاجة.`,
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true
    });
  }

  if (action === "audience" && interaction.isStringSelectMenu()) {
    const choice = interaction.values[0];
    if (choice === "everyone") {
      session.audience = { type: "everyone", roleId: "", userIds: [] };
      return interaction.update({ content: "تم اختيار Everyone.", components: [] });
    }
    const modal = new ModalBuilder()
      .setCustomId(`bcmodal:audience:${session.id}:${choice}`)
      .setTitle(choice === "role" ? "Select role" : "Select members");
    const input = new TextInputBuilder()
      .setCustomId("ids")
      .setLabel(choice === "role" ? "رقم الرتبة (Role ID)" : "أرقام المستخدمين مفصولة بفواصل")
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1800)
      .setPlaceholder(choice === "role" ? "123456789012345678" : "123456789012345678, 234567890123456789");
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    return interaction.showModal(modal);
  }

  if (action === "preview") {
    const preview = makePreview(session);
    return interaction.reply({
      content: "معاينة الرسالة (لن يتم الإرسال عند المعاينة):",
      ...(preview.content ? { content: `معاينة الرسالة:\n${preview.content}` } : {}),
      embeds: preview.embeds,
      ephemeral: true
    });
  }

  if (action === "send") {
    if (session.running) return interaction.reply({ content: "الحملة قيد التنفيذ بالفعل.", ephemeral: true });
    const confirm = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bc:confirm:${session.id}`).setLabel("Confirm Send").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`bc:cancel:${session.id}`).setLabel("Cancel").setStyle(ButtonStyle.Secondary)
    );
    return interaction.reply({
      content: "هل أنت متأكد من بدء الإرسال إلى الجمهور المحدد؟ لا يمكن استرجاع الرسائل التي وصلت بالفعل.",
      components: [confirm],
      ephemeral: true
    });
  }

  if (action === "confirm") {
    return runBroadcast(interaction, session);
  }

  if (action === "cancel") {
    session.cancelled = true;
    if (!session.running) sessions.delete(session.id);
    return interaction.update({ content: "تم إلغاء المسودة أو طلب إيقاف الحملة.", components: [], embeds: [] }).catch(() =>
      interaction.reply({ content: "تم إلغاء المسودة أو طلب إيقاف الحملة.", ephemeral: true })
    );
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isModalSubmit()) return;
  const parts = interaction.customId.split(":");
  if (parts[0] !== "bcmodal") return;
  const [, kind, sessionId, audienceType] = parts;
  const session = sessions.get(sessionId);
  if (!session || session.guildId !== interaction.guildId || (session.userId !== interaction.user.id && interaction.user.id !== OWNER_ID)) {
    return interaction.reply({ content: "انتهت صلاحية هذه اللوحة أو ليست لك.", ephemeral: true });
  }
  if (kind === "compose") {
    const mode = interaction.fields.getTextInputValue("mode").trim().toLowerCase();
    if (!["embed", "text"].includes(mode)) {
      return interaction.reply({ content: "اكتب النوع كـ embed أو text.", ephemeral: true });
    }
    const rawImage = interaction.fields.getTextInputValue("image").trim();
    const imageUrl = rawImage ? safeUrl(rawImage) : null;
    if (rawImage && !imageUrl) return interaction.reply({ content: "رابط الصورة غير صالح. استخدم رابط HTTP أو HTTPS.", ephemeral: true });
    session.content = {
      title: clampText(interaction.fields.getTextInputValue("title").trim(), 256),
      body: clampText(interaction.fields.getTextInputValue("body").trim(), 4000),
      imageUrl: imageUrl || "",
      mode
    };
    return interaction.reply({ content: "تم حفظ محتوى الرسالة. اضغط Preview لمراجعتها.", ephemeral: true });
  }
  if (kind === "audience") {
    const raw = interaction.fields.getTextInputValue("ids").trim();
    if (audienceType === "role") {
      if (!/^\d{15,22}$/.test(raw)) return interaction.reply({ content: "رقم الرتبة غير صحيح.", ephemeral: true });
      session.audience = { type: "role", roleId: raw, userIds: [] };
      return interaction.reply({ content: "تم حفظ الرتبة. راجع لوحة التحكم ثم Preview وSend.", ephemeral: true });
    }
    const ids = chunkIds(raw);
    if (!ids.length) return interaction.reply({ content: "لم أجد أرقام مستخدمين صحيحة. استخدم User IDs مفصولة بفواصل.", ephemeral: true });
    if (ids.length > 100) return interaction.reply({ content: "الحد الأقصى في الاختيار اليدوي هو 100 مستخدم في كل حملة.", ephemeral: true });
    session.audience = { type: "members", roleId: "", userIds: ids };
    return interaction.reply({ content: `تم حفظ ${ids.length} مستخدم/مستخدمين ضمن الجمهور.`, ephemeral: true });
  }
});

client.on("error", error => console.error("Discord client error:", error));
process.on("unhandledRejection", error => console.error("Unhandled rejection:", error));

for (const slot of botSlots) {
  if (!slot.token) continue;
  slot.client.login(slot.token).catch(error => {
    console.error(`Could not log in ${slot.tokenName}:`, error.message || error);
    if (slot.client === client) process.exitCode = 1;
  });
}
